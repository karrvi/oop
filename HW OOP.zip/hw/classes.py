import os.path


class CarBase:
    def __init__(self, photo_file_name: str, brand: str, carrying: float):
        if os.path.splitext(photo_file_name)[-1] not in [".jpg", ".jpeg", ".png", ".gif"]:
            raise ValueError

        self.photo_file_name = photo_file_name
        self.brand = brand
        self.carrying = carrying

    def get_photo_file_ext(self):
        return os.path.splitext(self.photo_file_name)[-1]


class Truck(CarBase):
    def __init__(self, photo_file_name: str, brand: str, carrying: float, body_whl: str):
        super().__init__(photo_file_name, brand, carrying)
        self.car_type = "truck"
        try:
            self.body_length, self.body_width, self.body_height = [float(x) for x in body_whl.split("x")]
        except ValueError:
            self.body_length, self.body_width, self.body_height = 0, 0, 0

    def get_body_volume(self):
        return self.body_height * self.body_width * self.body_length


class Car(CarBase):
    def __init__(self, photo_file_name: str, brand: str, carrying: float, passenger_seats_count: str):
        super().__init__(photo_file_name, brand, carrying)
        self.car_type = "car"
        self.passenger_seats_count = passenger_seats_count


class SpecMachine(CarBase):
    def __init__(self, photo_file_name: str, brand: str, carrying: float, extra: str):
        super().__init__(photo_file_name, brand, carrying)
        self.car_type = "spec_machine"
        self.extra = extra
