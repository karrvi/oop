import csv
import classes


def get_car_list(file_name):
    objects = []
    with open(file_name, newline='') as file:
        reader = csv.reader(file, delimiter=';')
        next(reader)
        for row in reader:
            try:
                car_type = row[0]
                if car_type == "car":
                    objects.append(classes.Car(row[3], row[1], float(row[5]), row[2]))
                elif car_type == "truck":
                    objects.append(classes.Truck(row[3], row[1], float(row[5]), row[4]))
                elif car_type == "spec_machine":
                    objects.append(classes.SpecMachine(row[3], row[1], float(row[5]), row[6]))
                else:
                    raise ValueError
            except ValueError:
                continue
    return objects


if __name__ == '__main__':
    cars = get_car_list("coursera_week3_cars.csv")
